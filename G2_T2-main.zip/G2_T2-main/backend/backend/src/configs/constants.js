//DATABASE 
const DB_Host = 'localhost';
const DB_User = 'root';
const DB_Password = 'password';
const DB_Database = 'database';
const DB_Port = 3306;


//SEVER_PORT
const SERVER_PORT = 4500;

module.exports = {
 DB_Host,
 DB_User,
 DB_Password,
 DB_Database,
 DB_Port,
 SERVER_PORT
}
